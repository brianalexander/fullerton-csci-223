// ============================================================================
// File: alloc_array.h (Spring 2019)
// ============================================================================

#ifndef ALLOC_ARRAY_H
#define ALLOC_ARRAY_H

// #include files
#include    "alloc_int.h"
#include    "alloc_char.h"
#include    "alloc_double.h"

// macros (use token-pasting operator to map function calls here...)
#define AllocArray(type, numElems) wlekfjwelfkwjeflkwjfweklj
#define ???
#define ???

#endif  // ALLOC_ARRAY_H
